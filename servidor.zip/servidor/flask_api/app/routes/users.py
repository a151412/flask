from flask import Blueprint, jsonify, request

users_bp = Blueprint('users', __name__)

# Lista inicial de usuários
users = [
    {'id': 1, 'name': 'User 1'},
    {'id': 2, 'name': 'User 2'}
]

# Função para gerar um novo ID único
def get_new_id():
    if users:
        return max(user['id'] for user in users) + 1
    else:
        return 1

# Rota para obter todos os usuários
@users_bp.route('/users', methods=['GET'])
def get_users():
    return jsonify({'users': users})

# Rota para adicionar um novo usuário
@users_bp.route('/users', methods=['POST'])
def add_user():
    new_user = request.json
    if 'name' not in new_user:
        return jsonify({'error': 'O campo "name" é obrigatório'}), 400

    new_user['id'] = get_new_id()
    users.append(new_user)
    return jsonify({'user': new_user}), 201

# Rota para obter um usuário específico pelo ID
@users_bp.route('/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = next((user for user in users if user['id'] == user_id), None)
    if user is None:
        return jsonify({'error': 'User não encontrado'}), 404
    return jsonify({'user': user})
