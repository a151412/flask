from flask import Blueprint, jsonify, request

items_bp = Blueprint('items', __name__)

items = [
    {'id': 1, 'name': 'Item 1'},
    {'id': 2, 'name': 'Item 2'},
    {'id': 3, 'name': 'Item 3'}
]

@items_bp.route('/items', methods=['GET'])
def get_items():
    return jsonify({'items': items})

@items_bp.route('/items', methods=['POST'])
def add_item():
    new_item = request.json
    if 'name' not in new_item:
        return jsonify({'error': 'O campo "name" é obrigatório'}), 400
    new_item['id'] = len(items) + 1
    items.append(new_item)
    return jsonify({'item': new_item}), 201

@items_bp.route('/items/<int:item_id>', methods=['GET'])
def get_item(item_id):
    item = next((item for item in items if item['id'] == item_id), None)
    if item is None:
        return jsonify({'error': 'Item não encontrado'}), 404
    return jsonify({'item': item})
