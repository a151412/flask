from flask import Flask

def create_app():
    app = Flask(__name__)

    with app.app_context():
        from .routes.home import home_bp
        from .routes.items import items_bp
        from .routes.users import users_bp  # Importar o novo Blueprint

        app.register_blueprint(home_bp)
        app.register_blueprint(items_bp)
        app.register_blueprint(users_bp)  # Registrar o novo Blueprint

    return app
